/********************************** (C) COPYRIGHT *******************************
* File Name          : IICHost.C
* Author             : WCH
* Version            : V1.0
* Date               : 2021/07/16
* Description        : ģ��IIC����
*******************************************************************************/
#include "IICHost.h"														

#pragma  NOAREGS



/*******************************************************************************
* Function Name  : I2C_Start
* Description    : ģ��I2C��ʼ�ź�
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void I2C_Start()
{
  SDA=1;
	mDelayuS(10);
	SCL=1;
  mDelayuS(10);
 	SDA=0;
	mDelayuS(10);
	SCL=0;
}
/*******************************************************************************
* Function Name  : I2C_Stop
* Description    : ģ��I2Cֹͣ�ź�
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void I2C_Stop()
{
    SCL=0;
		mDelayuS(10);
    SDA=0;
    mDelayuS(10);
    SCL=1;
		mDelayuS(10);
    SDA=1;
    mDelayuS(10);
		SCL=0;
}

//����ACKӦ��
void I2C_Ack(void)
{
	SCL=0;
	mDelayuS(10);
	SDA=0;
	mDelayuS(10);
	SCL=1;
	mDelayuS(10);
	SCL=0;
}

//������ACKӦ��		    
void I2C_NAck(void)
{
	SCL=0;
	mDelayuS(10);
	SDA=1;
	mDelayuS(10);
	SCL=1;
	mDelayuS(10);
	SCL=0;
}	

//�ȴ��ӻ�ACKӦ��
UINT8 I2C_Wait_Ack(void)
{
	UINT8 ucErrTime=0;
	SDA=1;
	mDelayuS(2);
	SCL=1;
  mDelayuS(2);	 
	while(SDA)
	{
		ucErrTime++;
		if(ucErrTime>200)
		{
			I2C_Stop();
			return 1;
		}
	}
	SCL=0;//ʱ�����0 
	mDelayuS(1);
	return 0;  
} 

//IIC����һ���ֽ�	  
void I2C_Send_Byte(UINT8 txd)
{                        
    UINT8 t;  
    SCL=0;//����ʱ�ӿ�ʼ���ݴ���
		mDelayuS(10);
    for(t=0;t<8;t++)
    {              
        SDA=(txd&0x80)>>7;
        txd<<=1; 	  
		mDelayuS(10);   //��TEA5767��������ʱ���Ǳ����
		SCL=1;
		mDelayuS(10); 
		SCL=0;	
		mDelayuS(10);
    }	 
} 	    

//��1���ֽڣ�ack=1ʱ������ACK��ack=0������nACK   
UINT8 I2C_Read_Byte(UINT8 ack)
{
	unsigned char i,receive=0;
    for(i=0;i<8;i++ )
	{
		SCL=0; 
		mDelayuS(10);
		SCL=1;
		mDelayuS(10);
		receive<<=1;
		if(SDA)receive++;   
		mDelayuS(1); 
  }	
	SCL=0;
	if (!ack)
			I2C_NAck();//����nACK
	else
			I2C_Ack(); //����ACK   
	mDelayuS(10); 
	return receive;
}
